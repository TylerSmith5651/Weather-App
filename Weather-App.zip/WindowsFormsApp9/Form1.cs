﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using System.IO;

namespace WindowsFormsApp9
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            {

                String zipCode = zipcode1.Text;
                //This will take the zip code that is entered in the text box and assign it so it can be used in the weather app
                // The URl will add that Zip code to the app and key we are using.
                String URL = "http://api.wunderground.com/api/589ead91dbd88efe/conditions/q/" + zipCode + ".xml";
                //Of course we then reach out to the internet for the data
                HttpClient client = new HttpClient();
                //See if we get an answer
                var serviceresponse = client.GetAsync(URL).Result;
                //Checks for a good status
                if (serviceresponse.IsSuccessStatusCode)
                {
                    var responseContent = serviceresponse.Content;
                    string responseString = responseContent.ReadAsStringAsync().Result;
                    XDocument doc = XDocument.Parse(responseString);
                    var result = from response in doc.Descendants("response")
                                 where response.Element("current_observation") != null && response.Element("current_observation").Element("temp_f") != null
                                 select response.Element("current_observation").Element("temp_f");
                   try
                    {
                        //Debug line of code
                        Debug.WriteLine(result.ElementAt(0).Value.ToString());
                        //And we have the temperature
                        tempText.Text = result.ElementAt(0).Value.ToString();

                        // Now to load in the icon
                        var icon = from response in doc.Descendants("response")
                                   where response.Element("current_observation") != null && response.Element("current_observation").Element("icon_url") != null
                                   select response.Element("current_observation").Element("icon_url");
                        //Debug the selected URL
                        Debug.WriteLine(icon.ElementAt(0).Value.ToString());
                        pictureBox1.Load(icon.ElementAt(0).Value.ToString());

                        //And finally add the location name
                        var locationName = from response in doc.Descendants("response")
                                           where response.Element("current_observation") != null && response.Element("current_observation").Element("display_location").Element("full") != null
                                           select response.Element("current_observation").Element("display_location").Element("full");
                        label2.Text = locationName.ElementAt(0).Value.ToString();
                    }
                    catch(System.ArgumentOutOfRangeException)
                    {
                        MessageBox.Show("There was an error with that Zip Code, please make sure to use a valid Zip Code");
                    }
                }


            }

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void zipcode1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
